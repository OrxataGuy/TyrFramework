import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import { homedir } from 'os';
import { ShellManager } from '../lib/ShellManager.js';
import { FileSystemManager } from '../lib/FileSystemManager.js';
import { PackageManager } from '../lib/PackageManager.js';
import { DockerManager } from '../lib/DockerManager.js';
import { GitManager } from '../lib/GitManager.js';
import { SystemManager } from '../lib/SystemManager.js';
import { SQLManager } from '../lib/SQLManager.js';
import { WebManager } from '../lib/WebManager.js';

export interface Logger {
    log(msg: any): void;
    info(msg: any): void;
    success(msg: any): void;
    error(msg: any): void;
    warn(msg: any): void;
}

export interface ServiceContainer {
    logger: Logger;
    shell: ShellManager;
    fs: FileSystemManager;
    pkg: PackageManager;
    docker: DockerManager;
    git: GitManager;
    sys: SystemManager;
    db: SQLManager;
    web: WebManager;
}

function createLogger(isDebug: boolean): Logger {
    const logDir = path.join(homedir(), '.tyr', 'logs');
    const logFile = path.join(logDir, `${new Date().toISOString().slice(0, 10)}.log`);

    fs.mkdirSync(logDir, { recursive: true });

    const writeToFile = (level: string, msg: any) => {
        const timestamp = new Date().toISOString();
        const line = `[${timestamp}] [${level}] ${String(msg)}\n`;
        fs.appendFileSync(logFile, line, 'utf-8');
    };

    return {
        log: (msg) => {
            console.log(msg);
            writeToFile('LOG', msg);
        },
        info: (msg) => {
            console.log(chalk.blue('ℹ'), msg);
            writeToFile('INFO', msg);
        },
        success: (msg) => {
            console.log(chalk.green('✔'), msg);
            writeToFile('SUCCESS', msg);
        },
        error: (msg) => {
            if (isDebug) console.error(chalk.red('✖'), msg);
            writeToFile('ERROR', msg);
        },
        warn: (msg) => {
            if (isDebug) console.warn(chalk.yellow('⚠'), msg);
            writeToFile('WARN', msg);
        },
    };
}

export class Container {
    private services: Partial<ServiceContainer>;

    constructor() {
        this.services = {};
    }

    public init(isDebug: boolean): void {
        const logger = createLogger(isDebug);
        const shell = new ShellManager();
        const db = new SQLManager();

        this.services = {
            logger,
            shell,
            db,
            web: new WebManager(logger),
            fs: new FileSystemManager(logger),
            pkg: new PackageManager(shell, logger),
            docker: new DockerManager(shell, logger),
            git: new GitManager(shell, logger),
            sys: new SystemManager(shell, logger),
        };
    }

    public get(): ServiceContainer {
        if (!this.services.logger) {
            throw new Error('Container not initialised. Call .init() first.');
        }
        return this.services as ServiceContainer;
    }
}
